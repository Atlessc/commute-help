# Phase 2.2d station cross-section acceptance policy

Flow-location eligibility only. Point speed remains ineligible and nothing is historically calibrated.

- Accepted stations: 356 / 426
- Accepted within-edge: 344
- Accepted edge-transition: 12
- Review: 69
- Unmatched: 1
- Direct profiles with all contributing stations flow-eligible: 88,585 / 112,265

Rules: direction is a hard gate; lateral distance must be at most 25 m; a point within 5 m of an internal shared boundary in a proven ordered chain becomes an edge-transition cross-section; other points within 25 m of a member boundary remain review.

The review Parquet is the bounded human-review package. Multiple stations remain independent.
